# Blender Cube Array Manager Addon

A comprehensive Blender addon for managing cube arrays and merging meshes with common faces.

## Features

### Feature Set 1: Cube Array Management
- **Input Validation**: Accept natural numbers N < 20 for cube count
- **Range Checking**: Display error popup if number exceeds 20
- **Smart Array Distribution**: Automatically arrange N cubes in optimal m×n 2D array
- **Separate Collection**: Organize cubes in dedicated collection
- **Delete Selected**: Remove selected cubes with single button click
- **Overlap Prevention**: New cubes avoid existing mesh positions

### Feature Set 2: Mesh Merging
- **Smart Merging**: Merge selected meshes into single mesh
- **Common Face Detection**: Automatically identify and process shared faces
- **Vertex Merging**: Combine common vertices at merge boundaries
- **Face Cleanup**: Remove duplicate faces at intersections

## Installation

### Method 1: Install from File
1. Open Blender
2. Go to Edit → Preferences → Add-ons
3. Click "Install..." button
4. Navigate to the `task2` folder
5. Select `__init__.py`
6. Click "Install Add-on"
7. Enable the addon by checking the checkbox next to "3D View: Cube Array Manager"

### Method 2: Manual Installation
1. Copy the entire `task2` folder to your Blender addons directory:
   - **Windows**: `C:\Users\{username}\AppData\Roaming\Blender Foundation\Blender\{version}\scripts\addons\`
   - **macOS**: `/Users/{username}/Library/Application Support/Blender/{version}/scripts/addons/`
   - **Linux**: `~/.config/blender/{version}/scripts/addons/`
2. Rename the folder to `cube_array_manager`
3. Restart Blender
4. Go to Edit → Preferences → Add-ons
5. Search for "Cube Array Manager"
6. Enable the addon

## Usage

### Accessing the Panel

After installation, you can find the addon panel:
1. Open the 3D Viewport
2. Press `N` to open the sidebar (if not already visible)
3. Click on the "Cube Manager" tab

### Feature Set 1: Creating Cube Arrays

1. **Set Number of Cubes**:
   - In the panel, find the "Number of Cubes" input field
   - Enter a number between 1 and 20
   - If you enter a number > 20, you'll see a warning message

2. **Create Cubes**:
   - Click the "Create Cube Array" button
   - Cubes will be arranged in an optimal m×n grid
   - Each cube has dimensions 1×1×1 Blender units
   - Cubes are spaced 2 units apart (1 unit gap)
   - All cubes are added to the "Cube_Array_Collection"

3. **Delete Selected Cubes**:
   - Select one or more cubes in the 3D viewport
   - Click the "Delete Selected Cubes" button
   - Selected objects will be removed

### Feature Set 2: Merging Meshes

1. **Prepare Meshes**:
   - Create or position meshes so they share at least one common face
   - For example, place two cubes adjacent to each other

2. **Merge**:
   - Select the meshes you want to merge (Shift+Click to select multiple)
   - Click the "Merge Selected Meshes" button
   - The meshes will be combined into a single object
   - Common vertices are merged
   - Overlapping faces are removed

## Examples

### Example 1: Creating a 3×3 Cube Array
```
1. Set "Number of Cubes" to 9
2. Click "Create Cube Array"
3. Result: 3×3 grid of cubes
```

### Example 2: Creating Custom Arrangements
```
1. Create 4 cubes
2. Manually reposition them
3. Create 12 more cubes
4. New cubes will avoid overlapping with existing ones
```

### Example 3: Merging Adjacent Cubes
```
1. Create 2 cubes
2. Position them adjacent (touching faces)
3. Select both cubes
4. Click "Merge Selected Meshes"
5. Result: Single merged mesh with shared face removed
```

## Technical Details

### Cube Distribution Algorithm
The addon uses a smart algorithm to calculate optimal grid dimensions:
- For N cubes, it calculates m = ⌈√N⌉
- Then n = ⌈N/m⌉
- This creates the most square-like arrangement possible

### Overlap Prevention
- Tracks positions of all existing meshes
- Uses a grid-based positioning system
- Automatically finds free positions for new cubes
- Prevents overlapping with any existing objects

### Mesh Merging Process
1. Joins selected meshes into single object
2. Enters edit mode
3. Removes duplicate vertices (merge by distance)
4. Deletes interior faces
5. Returns to object mode

## Addon Information

- **Name**: Cube Array Manager
- **Category**: 3D View
- **Blender Version**: 3.0.0+
- **Location**: View3D > Sidebar > Cube Manager

## UI Panel Structure

```
┌─────────────────────────────────┐
│ Cube Array Manager              │
├─────────────────────────────────┤
│ Feature Set 1: Cube Array       │
│ ┌─────────────────────────────┐ │
│ │ Number of Cubes: [input]    │ │
│ │ [Create Cube Array]         │ │
│ │ [Delete Selected Cubes]     │ │
│ └─────────────────────────────┘ │
│                                 │
│ Feature Set 2: Mesh Merging     │
│ ┌─────────────────────────────┐ │
│ │ [Merge Selected Meshes]     │ │
│ │                             │ │
│ │ ℹ Select meshes with common │ │
│ │   faces to merge them       │ │
│ └─────────────────────────────┘ │
└─────────────────────────────────┘
```

## Troubleshooting

### Addon Not Appearing
- Check that you enabled it in Preferences → Add-ons
- Try restarting Blender
- Check the System Console for error messages

### "Number is out of range" Error
- This is expected behavior when entering a number > 20
- Simply enter a number ≤ 20

### Merge Not Working
- Ensure you have at least 2 meshes selected
- Verify the meshes are actually touching/overlapping
- Check that selected objects are mesh type (not curves, empties, etc.)

### Cubes Not Creating in Expected Pattern
- This is normal if existing meshes occupy those positions
- The addon automatically finds free positions
- Delete existing meshes if you want a clean grid

## Keyboard Shortcuts

While the addon doesn't add custom shortcuts, these Blender shortcuts are useful:

- `Shift + A`: Add menu (for manual object creation)
- `X`: Delete selected objects
- `G`: Grab/move objects
- `N`: Toggle sidebar (where addon panel is located)
- `Shift + Click`: Select multiple objects

## File Structure

```
task2/
└── __init__.py  (Main addon file)
```

## Requirements

- Blender 3.0.0 or higher
- No external Python dependencies

## Known Limitations

1. Maximum 20 cubes per creation operation (by design)
2. Merge operation works best with meshes that have flat, aligned common faces
3. Overlap prevention is grid-based (2-unit spacing)

## Future Enhancements

Potential improvements for future versions:
- Variable cube sizes
- Custom spacing options
- More sophisticated merge algorithms
- Undo/redo history for all operations
- Batch operations on collections

## Contributing

Contributions and suggestions are welcome! Please consider:
- Code readability and comments
- Blender API best practices
- User experience improvements
- Performance optimizations

## License

MIT License

## Support

For issues, questions, or suggestions:
- Check the Blender Console for error messages (Window → Toggle System Console)
- Review this documentation
- Check Blender addon development documentation

## Credits

Developed for the CFD-FOSSEE OpenFOAM GUI Project screening task.

## Version History

- **v1.0.0** (Initial Release)
  - Cube array creation with validation
  - Smart grid distribution algorithm
  - Collection organization
  - Delete selected functionality
  - Overlap prevention
  - Mesh merging with common face detection
