"""
Blender Addon for Cube Array Management and Mesh Merging
This addon provides UI panels for creating cube arrays and merging meshes.
"""

bl_info = {
    "name": "Cube Array Manager",
    "author": "Your Name",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Cube Manager",
    "description": "Create and manage cube arrays, merge meshes with common faces",
    "category": "3D View",
}

import bpy
import bmesh
import math
from mathutils import Vector
from bpy.props import IntProperty
from bpy.types import Panel, Operator, PropertyGroup


# ============================================================================
# Properties
# ============================================================================

class CubeArrayProperties(PropertyGroup):
    """Properties for the Cube Array Manager."""
    
    num_cubes: IntProperty(
        name="Number of Cubes",
        description="Number of cubes to create (max 20)",
        default=1,
        min=1,
        max=20
    )


# ============================================================================
# Operators
# ============================================================================

class CUBEARRAY_OT_CreateCubes(Operator):
    """Create an array of cubes in the 3D viewport."""
    bl_idname = "cubearray.create_cubes"
    bl_label = "Create Cube Array"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.cube_array_props
        num_cubes = props.num_cubes
        
        # Validate input
        if num_cubes > 20:
            self.report({'ERROR'}, "The number is out of range")
            return {'CANCELLED'}
        
        # Calculate grid dimensions (m x n)
        # Try to make it as square as possible
        m = int(math.ceil(math.sqrt(num_cubes)))
        n = int(math.ceil(num_cubes / m))
        
        # Create or get the collection for cubes
        collection_name = "Cube_Array_Collection"
        if collection_name in bpy.data.collections:
            cube_collection = bpy.data.collections[collection_name]
        else:
            cube_collection = bpy.data.collections.new(collection_name)
            context.scene.collection.children.link(cube_collection)
        
        # Get existing cubes to avoid overlap
        existing_positions = set()
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                pos = obj.location
                # Round to grid positions
                grid_x = round(pos.x / 2.0)
                grid_y = round(pos.y / 2.0)
                existing_positions.add((grid_x, grid_y))
        
        # Create cubes
        cubes_created = 0
        spacing = 2.0  # Space between cubes (cube size + gap)
        
        for i in range(m):
            for j in range(n):
                if cubes_created >= num_cubes:
                    break
                
                # Calculate position with overlap avoidance
                grid_x = i
                grid_y = j
                
                # Find a free position if this one is occupied
                offset = 0
                while (grid_x, grid_y) in existing_positions:
                    offset += 1
                    grid_x = i + offset
                    if grid_x >= m + 10:  # Safety limit
                        grid_y += 1
                        grid_x = i
                
                x = grid_x * spacing
                y = grid_y * spacing
                z = 0.0
                
                # Create cube
                bpy.ops.mesh.primitive_cube_add(size=1.0, location=(x, y, z))
                cube = context.active_object
                cube.name = f"Cube_{cubes_created + 1}"
                
                # Move to collection
                for coll in cube.users_collection:
                    coll.objects.unlink(cube)
                cube_collection.objects.link(cube)
                
                # Mark position as occupied
                existing_positions.add((grid_x, grid_y))
                
                cubes_created += 1
            
            if cubes_created >= num_cubes:
                break
        
        self.report({'INFO'}, f"Created {cubes_created} cubes in {m}x{n} array")
        return {'FINISHED'}


class CUBEARRAY_OT_DeleteSelected(Operator):
    """Delete selected cubes."""
    bl_idname = "cubearray.delete_selected"
    bl_label = "Delete Selected Cubes"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        selected_objects = context.selected_objects
        
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        # Delete selected objects
        bpy.ops.object.delete()
        
        self.report({'INFO'}, f"Deleted {len(selected_objects)} object(s)")
        return {'FINISHED'}


class CUBEARRAY_OT_MergeMeshes(Operator):
    """Merge selected meshes with common faces."""
    bl_idname = "cubearray.merge_meshes"
    bl_label = "Merge Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if len(selected_objects) < 2:
            self.report({'ERROR'}, "Select at least 2 meshes to merge")
            return {'CANCELLED'}
        
        # Check for common faces and merge
        merged = self.merge_meshes_with_common_faces(context, selected_objects)
        
        if merged:
            self.report({'INFO'}, f"Successfully merged {len(selected_objects)} meshes")
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "No common faces found between meshes")
            return {'CANCELLED'}
    
    def merge_meshes_with_common_faces(self, context, objects):
        """
        Merge meshes that have common faces.
        Returns True if merge was successful.
        """
        if not objects:
            return False
        
        # Deselect all
        bpy.ops.object.select_all(action='DESELECT')
        
        # Select all meshes to merge
        for obj in objects:
            obj.select_set(True)
        
        # Set the first object as active
        context.view_layer.objects.active = objects[0]
        
        # Join the objects
        bpy.ops.object.join()
        
        # Get the merged object
        merged_obj = context.active_object
        
        # Enter edit mode to remove duplicate vertices and faces
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Select all geometry
        bpy.ops.mesh.select_all(action='SELECT')
        
        # Remove doubles (merge vertices by distance)
        bpy.ops.mesh.remove_doubles(threshold=0.0001)
        
        # Delete interior faces (faces that are completely inside)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_interior_faces()
        bpy.ops.mesh.delete(type='FACE')
        
        # Return to object mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        return True


# ============================================================================
# UI Panel
# ============================================================================

class CUBEARRAY_PT_MainPanel(Panel):
    """Main panel for Cube Array Manager."""
    bl_label = "Cube Array Manager"
    bl_idname = "CUBEARRAY_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Cube Manager'
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.cube_array_props
        
        # Feature Set 1
        box = layout.box()
        box.label(text="Feature Set 1: Cube Array", icon='MESH_CUBE')
        
        # Input for number of cubes
        box.prop(props, "num_cubes")
        
        # Validation warning
        if props.num_cubes > 20:
            row = box.row()
            row.alert = True
            row.label(text="Number exceeds limit!", icon='ERROR')
        
        # Create cubes button
        box.operator("cubearray.create_cubes", icon='ADD')
        
        # Delete selected button
        box.operator("cubearray.delete_selected", icon='TRASH')
        
        # Feature Set 2
        box = layout.box()
        box.label(text="Feature Set 2: Mesh Merging", icon='AUTOMERGE_ON')
        
        # Merge meshes button
        box.operator("cubearray.merge_meshes", icon='PIVOT_BOUNDBOX')
        
        # Info
        info_box = box.box()
        info_box.label(text="Select meshes with common faces", icon='INFO')
        info_box.label(text="to merge them together")


# ============================================================================
# Registration
# ============================================================================

classes = (
    CubeArrayProperties,
    CUBEARRAY_OT_CreateCubes,
    CUBEARRAY_OT_DeleteSelected,
    CUBEARRAY_OT_MergeMeshes,
    CUBEARRAY_PT_MainPanel,
)


def register():
    """Register addon classes and properties."""
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.cube_array_props = bpy.props.PointerProperty(type=CubeArrayProperties)


def unregister():
    """Unregister addon classes and properties."""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.cube_array_props


if __name__ == "__main__":
    register()
