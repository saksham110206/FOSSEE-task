# Binary Tree Package with YAML Integration

A comprehensive Python package for creating, manipulating, and persisting binary trees with YAML support.

## Features

### Feature Set 1: Core Binary Tree Operations
- **Node Class**: Basic building block for binary tree construction
- **Tree Creation**: Create binary trees manually or programmatically
- **Add Nodes**: Add nodes to existing trees using path notation (e.g., "LR" for left-then-right)
- **Delete Nodes**: Remove individual nodes or entire trees
- **Print Tree**: Visualize tree structure in console
- **Edit Values**: Modify node values in-place
- **Print Range**: Display specific levels of the tree

### Feature Set 2: YAML Integration
- **Import from YAML**: Build binary trees from YAML configuration files
- **Export to YAML**: Save tree structures to YAML format for persistence

## Installation

### Method 1: Direct Installation
```bash
cd task1
pip install -e .
```

### Method 2: Using requirements.txt
```bash
cd task1
pip install -r requirements.txt
pip install -e .
```

## Quick Start

```python
from binarytree import Node, print_tree, add_node_by_path

# Create a simple tree
root = Node(10)
root.left = Node(5)
root.right = Node(15)

# Print the tree
print_tree(root)

# Add nodes by path
add_node_by_path(root, "LL", 3)  # Add left-left child
add_node_by_path(root, "RR", 20) # Add right-right child

print_tree(root)
```

## Usage Examples

### Creating and Manipulating Trees

```python
from binarytree import *

# Create a root node
root = Node(1)

# Add children manually
root.left = Node(2)
root.right = Node(3)
root.left.left = Node(4)
root.left.right = Node(5)

# Print the tree
print_tree(root)
```

### Adding Nodes by Path

```python
root = Node(10)

# Path notation: 'L' for left, 'R' for right
add_node_by_path(root, "L", 5)      # Add left child
add_node_by_path(root, "R", 15)     # Add right child
add_node_by_path(root, "LL", 3)     # Add left-left grandchild
add_node_by_path(root, "LR", 7)     # Add left-right grandchild
add_node_by_path(root, "RL", 12)    # Add right-left grandchild
add_node_by_path(root, "RR", 18)    # Add right-right grandchild

print_tree(root)
```

### YAML Integration

#### Import from YAML
```python
# Create test.yaml file with tree structure
yaml_tree_root = build_tree_from_yaml("test.yaml")
print_tree(yaml_tree_root)
```

Example `test.yaml`:
```yaml
value: 10
left:
  value: 5
  left:
    value: 3
  right:
    value: 7
right:
  value: 15
  right:
    value: 18
```

#### Export to YAML
```python
# Save tree to YAML
write_tree_to_yaml(root, "output.yaml")
```

### Editing Node Values

```python
# Change value 7 to 77
edit_node_value(root, 7, 77)
print_tree(root)
```

### Deleting Nodes

```python
# Delete a specific node
root = delete_node(root, 5)

# Delete entire tree
delete_tree(root)
```

### Printing Tree Range

```python
# Print only levels 0 and 1
print_tree_range(root, min_level=0, max_level=1)
```

## Running the Test Script

The package includes a comprehensive test script that demonstrates all features:

```bash
cd task1
python main.py
```

## API Reference

### Classes

#### `Node`
```python
Node(value)
```
Creates a new node with the given value.

**Attributes:**
- `value`: The value stored in the node
- `left`: Reference to left child (default: None)
- `right`: Reference to right child (default: None)

### Functions

#### `print_tree(root, prefix="Root:", is_left=True, level=0)`
Prints the entire binary tree in a visual format.

**Parameters:**
- `root`: The root node of the tree
- `prefix`: Prefix string for the current node (default: "Root:")
- `is_left`: Whether the current node is a left child (default: True)
- `level`: Current depth level in the tree (default: 0)

#### `print_tree_range(root, min_level=0, max_level=float('inf'))`
Prints a specific range of levels in the binary tree.

**Parameters:**
- `root`: The root node of the tree
- `min_level`: Minimum level to print (default: 0)
- `max_level`: Maximum level to print (default: infinity)

#### `add_node_by_path(root, path, value)`
Adds a node to the binary tree following a path string.

**Parameters:**
- `root`: The root node of the tree
- `path`: A string where 'L' means left and 'R' means right
- `value`: The value to store in the new node

**Returns:** The root node of the tree

#### `delete_node(root, value)`
Deletes a node with the specified value from the binary tree.

**Parameters:**
- `root`: The root node of the tree
- `value`: The value of the node to delete

**Returns:** The root node of the modified tree

#### `delete_tree(root)`
Deletes the entire binary tree.

**Parameters:**
- `root`: The root node of the tree to delete

#### `edit_node_value(root, old_value, new_value)`
Edits the value of a node in the binary tree.

**Parameters:**
- `root`: The root node of the tree
- `old_value`: The current value of the node to edit
- `new_value`: The new value to set

**Returns:** True if the node was found and edited, False otherwise

#### `build_tree_from_yaml(yaml_file)`
Builds a binary tree from a YAML file.

**Parameters:**
- `yaml_file`: Path to the YAML file

**Returns:** The root node of the constructed tree

#### `write_tree_to_yaml(root, yaml_file)`
Writes a binary tree to a YAML file.

**Parameters:**
- `root`: The root node of the tree
- `yaml_file`: Path to the output YAML file

**Returns:** True if successful, False otherwise

## Requirements

- Python >= 3.7
- PyYAML >= 5.4.1

## Testing

Run the included test script to verify all functionality:

```bash
python main.py
```

Expected output includes:
1. Basic tree creation and printing
2. Adding nodes by path
3. YAML import/export
4. Node value editing
5. Tree range printing
6. Node deletion

## Project Structure

```
task1/
├── binarytree/
│   ├── __init__.py
│   ├── node.py
│   └── tree_operations.py
├── setup.py
├── requirements.txt
├── main.py
├── test.yaml
└── README.md
```

## License

MIT License

## Author

Your Name (your.email@example.com)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
