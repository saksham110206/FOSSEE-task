"""
Node class for Binary Tree implementation.
"""

class Node:
    """
    A node in a binary tree.
    
    Attributes:
        value: The value stored in the node
        left: Reference to the left child node
        right: Reference to the right child node
    """
    
    def __init__(self, value):
        """
        Initialize a new node.
        
        Args:
            value: The value to store in the node
        """
        self.value = value
        self.left = None
        self.right = None
    
    def __repr__(self):
        """String representation of the node."""
        return f"Node({self.value})"
    
    def __str__(self):
        """String representation for printing."""
        return str(self.value)
