"""
Tree operations module with helper functions for binary tree manipulation.
"""

import yaml
from typing import Optional, Any, List
from .node import Node


def print_tree(root: Optional[Node], prefix: str = "Root:", is_left: bool = True, level: int = 0) -> None:
    """
    Print the entire binary tree in a visual format.
    
    Args:
        root: The root node of the tree
        prefix: Prefix string for the current node
        is_left: Whether the current node is a left child
        level: Current depth level in the tree
    """
    if root is None:
        return
    
    print(prefix + str(root.value))
    
    # Print left subtree
    if root.left is not None or root.right is not None:
        if root.left:
            new_prefix = " " * (len(prefix) - 5) + " L---" if level > 0 else " L---"
            print_tree(root.left, new_prefix, True, level + 1)
        
        # Print right subtree
        if root.right:
            new_prefix = " " * (len(prefix) - 5) + " R---" if level > 0 else " R---"
            print_tree(root.right, new_prefix, False, level + 1)


def print_tree_range(root: Optional[Node], min_level: int = 0, max_level: int = float('inf')) -> None:
    """
    Print a specific range of levels in the binary tree.
    
    Args:
        root: The root node of the tree
        min_level: Minimum level to print (0-indexed)
        max_level: Maximum level to print (inclusive)
    """
    def print_level_range(node: Optional[Node], prefix: str = "Root:", 
                         is_left: bool = True, current_level: int = 0) -> None:
        if node is None or current_level > max_level:
            return
        
        if current_level >= min_level:
            print(prefix + str(node.value))
        
        if node.left is not None or node.right is not None:
            if node.left:
                new_prefix = " " * (len(prefix) - 5) + " L---" if current_level > 0 else " L---"
                print_level_range(node.left, new_prefix, True, current_level + 1)
            
            if node.right:
                new_prefix = " " * (len(prefix) - 5) + " R---" if current_level > 0 else " R---"
                print_level_range(node.right, new_prefix, False, current_level + 1)
    
    print_level_range(root)


def add_node_by_path(root: Optional[Node], path: str, value: Any) -> Optional[Node]:
    """
    Add a node to the binary tree following a path string.
    
    Args:
        root: The root node of the tree
        path: A string where 'L' means left and 'R' means right (e.g., "LR" means left then right)
        value: The value to store in the new node
    
    Returns:
        The root node of the tree
    """
    if root is None:
        return Node(value)
    
    if not path:
        return root
    
    current = root
    for i, direction in enumerate(path[:-1]):
        if direction == 'L':
            if current.left is None:
                current.left = Node(None)
            current = current.left
        elif direction == 'R':
            if current.right is None:
                current.right = Node(None)
            current = current.right
        else:
            raise ValueError(f"Invalid direction '{direction}' in path. Use 'L' or 'R'.")
    
    # Add the final node
    if path[-1] == 'L':
        current.left = Node(value)
    elif path[-1] == 'R':
        current.right = Node(value)
    else:
        raise ValueError(f"Invalid direction '{path[-1]}' in path. Use 'L' or 'R'.")
    
    return root


def delete_node(root: Optional[Node], value: Any) -> Optional[Node]:
    """
    Delete a node with the specified value from the binary tree.
    Uses the standard BST deletion algorithm.
    
    Args:
        root: The root node of the tree
        value: The value of the node to delete
    
    Returns:
        The root node of the modified tree
    """
    if root is None:
        return None
    
    # Search for the node to delete
    if value < root.value:
        root.left = delete_node(root.left, value)
    elif value > root.value:
        root.right = delete_node(root.right, value)
    else:
        # Node found - handle deletion
        # Case 1: Node with only one child or no child
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left
        
        # Case 2: Node with two children
        # Get the inorder successor (smallest in the right subtree)
        min_larger_node = _find_min(root.right)
        root.value = min_larger_node.value
        root.right = delete_node(root.right, min_larger_node.value)
    
    return root


def _find_min(node: Node) -> Node:
    """Find the node with minimum value in a tree."""
    current = node
    while current.left is not None:
        current = current.left
    return current


def delete_tree(root: Optional[Node]) -> None:
    """
    Delete the entire binary tree.
    
    Args:
        root: The root node of the tree to delete
    """
    if root is None:
        return
    
    # Post-order traversal to delete all nodes
    delete_tree(root.left)
    delete_tree(root.right)
    
    # Clear the node
    root.left = None
    root.right = None
    root.value = None


def edit_node_value(root: Optional[Node], old_value: Any, new_value: Any) -> bool:
    """
    Edit the value of a node in the binary tree.
    
    Args:
        root: The root node of the tree
        old_value: The current value of the node to edit
        new_value: The new value to set
    
    Returns:
        True if the node was found and edited, False otherwise
    """
    if root is None:
        return False
    
    if root.value == old_value:
        root.value = new_value
        return True
    
    # Search in left and right subtrees
    return edit_node_value(root.left, old_value, new_value) or \
           edit_node_value(root.right, old_value, new_value)


def build_tree_from_yaml(yaml_file: str) -> Optional[Node]:
    """
    Build a binary tree from a YAML file.
    
    Args:
        yaml_file: Path to the YAML file
    
    Returns:
        The root node of the constructed tree
    """
    try:
        with open(yaml_file, 'r') as file:
            data = yaml.safe_load(file)
        
        if data is None:
            return None
        
        return _build_tree_from_dict(data)
    
    except FileNotFoundError:
        print(f"Error: File '{yaml_file}' not found.")
        return None
    except yaml.YAMLError as e:
        print(f"Error parsing YAML file: {e}")
        return None


def _build_tree_from_dict(data: dict) -> Optional[Node]:
    """
    Recursively build a tree from a dictionary.
    
    Args:
        data: Dictionary containing tree structure
    
    Returns:
        The root node of the constructed tree
    """
    if data is None:
        return None
    
    if not isinstance(data, dict) or 'value' not in data:
        return None
    
    root = Node(data['value'])
    
    if 'left' in data:
        root.left = _build_tree_from_dict(data['left'])
    
    if 'right' in data:
        root.right = _build_tree_from_dict(data['right'])
    
    return root


def write_tree_to_yaml(root: Optional[Node], yaml_file: str) -> bool:
    """
    Write a binary tree to a YAML file.
    
    Args:
        root: The root node of the tree
        yaml_file: Path to the output YAML file
    
    Returns:
        True if successful, False otherwise
    """
    try:
        tree_dict = _tree_to_dict(root)
        
        with open(yaml_file, 'w') as file:
            yaml.dump(tree_dict, file, default_flow_style=False, sort_keys=False)
        
        return True
    
    except Exception as e:
        print(f"Error writing to YAML file: {e}")
        return False


def _tree_to_dict(node: Optional[Node]) -> Optional[dict]:
    """
    Convert a tree to a dictionary representation.
    
    Args:
        node: The current node
    
    Returns:
        Dictionary representation of the tree
    """
    if node is None:
        return None
    
    result = {'value': node.value}
    
    if node.left is not None:
        result['left'] = _tree_to_dict(node.left)
    
    if node.right is not None:
        result['right'] = _tree_to_dict(node.right)
    
    return result
