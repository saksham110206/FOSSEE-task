"""
Test script for the binary tree package.
"""

from binarytree import *

if __name__ == "__main__":
    # Test 1: Basic tree creation
    print("=" * 50)
    print("Test 1: Basic Tree Creation")
    print("=" * 50)
    root = Node(1)
    root.left = Node(2)
    root.right = Node(3)
    root.left.left = Node(4)
    root.left.right = Node(5)
    print_tree(root)
    
    # Test 2: Adding nodes by path
    print("\n" + "=" * 50)
    print("Test 2: Adding Nodes by Path")
    print("=" * 50)
    root = Node(10)
    print("Initial tree:")
    print_tree(root)
    
    # Add nodes
    print("\nAdding nodes:")
    add_node_by_path(root, "L", 5)
    add_node_by_path(root, "R", 15)
    add_node_by_path(root, "LL", 3)
    add_node_by_path(root, "LR", 7)
    add_node_by_path(root, "RL", 12)
    add_node_by_path(root, "RR", 18)
    print("\nTree after additions:")
    print_tree(root)
    
    # Test 3: YAML integration
    print("\n" + "=" * 50)
    print("Test 3: YAML Integration")
    print("=" * 50)
    yaml_file = "test.yaml"
    print(f"\nBuilding tree from '{yaml_file}':")
    yaml_tree_root = build_tree_from_yaml(yaml_file)
    if yaml_tree_root:
        print("\nTree built from YAML:")
        print_tree(yaml_tree_root)
    
    # Test 4: Write tree to YAML
    print("\n" + "=" * 50)
    print("Test 4: Write Tree to YAML")
    print("=" * 50)
    output_file = "output_tree.yaml"
    success = write_tree_to_yaml(root, output_file)
    if success:
        print(f"Tree successfully written to '{output_file}'")
        print("\nVerifying by reading back:")
        verified_root = build_tree_from_yaml(output_file)
        if verified_root:
            print_tree(verified_root)
    
    # Test 5: Edit node value
    print("\n" + "=" * 50)
    print("Test 5: Edit Node Value")
    print("=" * 50)
    print("Before editing:")
    print_tree(root)
    edit_node_value(root, 7, 77)
    print("\nAfter editing value 7 to 77:")
    print_tree(root)
    
    # Test 6: Print tree range
    print("\n" + "=" * 50)
    print("Test 6: Print Tree Range (Levels 0-1)")
    print("=" * 50)
    print_tree_range(root, 0, 1)
    
    # Test 7: Delete node
    print("\n" + "=" * 50)
    print("Test 7: Delete Node")
    print("=" * 50)
    print("Before deletion:")
    print_tree(root)
    root = delete_node(root, 5)
    print("\nAfter deleting node with value 5:")
    print_tree(root)
